#ifndef _SINK_H_
#define _SINK_H_
char *abcd_sink(const char *, const char *);
int add_sink(int , int );
int multip_sink(int , int );

#endif
